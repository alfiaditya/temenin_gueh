<?php

//udah nge get id event

//get detail event
$event=mysqli_query($conn,"SELECT *, DATE_FORMAT(tanggal, \"%w %Y %m %d\"), TIME_FORMAT(waktu, \"%H.%i WIB\") FROM tb_event, tb_kategori WHERE id_event=$id_event AND tb_kategori.id_kategori=tb_event.id_kategori");
$c=mysqli_fetch_array($event);
$id_event = $c['id_event'];
$nama_event = $c['nama_event'];
$deskripsi = $c['deskripsi'];
$kategori = $c['nama_kategori'];
$jumlah_peserta = $c['jumlah_peserta'];

//format tanggal
$tanggal = $c['DATE_FORMAT(tanggal, "%w %Y %m %d")'];
$hari_indo = array("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu");
$bulan_indo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
$hr = substr($tanggal, 0, 1);
$thn = substr($tanggal, 2, 4);
$bln = substr($tanggal, 7, 2);
$tgl = substr($tanggal, 10, 2);
$tanggal_reg = $hari_indo[(int)$hr].", ".$tgl." ".$bulan_indo[(int)$bln-1]." ".$thn;

//format waktu
$waktu = $c['TIME_FORMAT(waktu, "%H.%i WIB")'];

$lokasi = $c['lokasi'];
$biaya = number_format($c['biaya'], 0,"",".") ;
$banner = $c['banner_event'];
$pj_event = $c['pj_event'];

//get jumlah peserta yang join event
$jum=mysqli_query($conn,"SELECT COUNT(id_join) FROM tb_join WHERE id_event=$id_event");
$j=mysqli_fetch_array($jum);
$jumlah_peserta_join = $j['COUNT(id_join)'];

//hapus
if(isset($_GET['hapus'])) {
    $id_join=$_GET['hapus'];

    if($id_member!=$pj_event){
        $hasil=mysqli_query($conn,"DELETE FROM tb_join WHERE id_join='$id_join'");
        header("location:event.php?id_event=$id_event");
    }
}
?>
<div class="container">

    <h1 class="mt-4 mb-3">Detail Event</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="event.php">Event</a>
        </li>
        <li class="breadcrumb-item active">Event #<?php echo $id_event;?></li>
    </ol>

    <div class="row">
        <div class="col-md-8">
            <img class="img-fluid" style="width:100%; height: 450px;" src="images/event/<?php echo $banner;?>" alt="<?php echo $banner ?>">
        </div>
        <div class="col-md-4 text-center">
            <h2 class="my-3"><?php echo $nama_event;?></h2>
            <h6 class="my-3"><i>Kategori <?php echo $kategori;?></i></h6>
            <h4 class="my-3">Deskripsi</h4>
            <p><?php echo $deskripsi;?></p>
            <h4 class="my-3">Detail Event</h4>
            <p>Peserta : (<?php echo $jumlah_peserta_join;?> dari <?php echo $jumlah_peserta;?>)<br/>
            Hari/Tanggal : <?php echo $tanggal_reg;?><br/>
            Waktu : <?php echo $waktu;?><br/>
            Tempat : <?php echo $lokasi;?><br/>
            Biaya : Rp. <?php echo $biaya;?></p><br/>
            <?php

            //check sudah gabung atau belum
            if(isset($_SESSION['id_member'])){
                $is_join=mysqli_query($conn,"SELECT * FROM tb_join WHERE id_member=$id_member AND id_event=$id_event");
                $ij=mysqli_fetch_array($is_join);
                $id_join = $ij['id_join'] ?? '';
                if($ij){
                    echo "<a href=\"event.php?id_event=$id_event&hapus=$id_join\" class=\"btn btn-danger\" onclick=\"keluar()\" >Keluar Event</a>";
                }
                else{
                    //mengecek jika peserta sudah full
                    if ($jumlah_peserta_join<$jumlah_peserta) {
                        echo "<a href=\"_join.php?id_event=$id_event\" class=\"btn btn-primary\" onclick=\"myFunction()\"  >Gabung Event</a>";
                    }
                    else{
                        echo "<a href=\"#\" class=\"btn btn-danger\">Peserta Event Full</a>";
                    }
                }
            }
            else{
                echo "<a href=\"login.php\" class=\"btn btn-primary\">Jika ingin bergabung anda harus Login</a>";
            }
            ?>
        </div>
    </div>
    <h3 class="my-4">Peserta Event</h3>
    <div class="row">
        <?php
        $member=mysqli_query($conn,"SELECT * FROM tb_member, tb_join WHERE tb_member.id_member=tb_join.id_member AND tb_join.id_event=$id_event");

        while($c=mysqli_fetch_array($member)){
            $id_event = $c['id_event'];
            $nama_member = $c['nama_member'];
            $email = $c['email'];
            $no_hp = $c['no_hp'];
            $foto = $c['foto'];
        ?>
        <div class="col-md-3 col-sm-6 mb-4">
            <div class="card h-80 text-center">
                <img class="img-fluid" src="images/foto/<?php echo $foto;?>" style="height: 210px;" alt="">
                <div class="card-body">
                    <h4 class="card-title"><?php echo $nama_member;?></h4>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo $no_hp;?></h6>
                </div>
                <div class="card-footer">
                    <a href="#"><?php echo $email;?></a>
                </div>
            </div>
        </div>
        <?php }?>
    </div>
    <?php
        if(isset($_SESSION['id_member'])){
            $id_member = $_SESSION['id_member'];
            $member=mysqli_query($conn,"SELECT * FROM tb_member WHERE id_member=$id_member");
            $c=mysqli_fetch_array($member);
            $nama_member = $c['nama_member'];
        }
        else{
            $nama_member = "";
        }
    ?>
    
    <h3 class="my-4">Chatroom (<?php echo $nama_member; ?>)</h3>
    <div class="row">
        <div class="col-md-12 col-sm-12 mb-4">
            <div class="chat">
                <?php 
                if(isset($id_join)){
                    include("chatbox.php");
                }
                else if(!isset($_SESSION['id_member'])){
                    echo "Anda belum login !";
                }
                else if(isset($_SESSION['id_member'])){
                    echo "Anda belum gabung event !";
                }
                ?>
            </div>
        </div>
    </div>
</div>
<script>
function myFunction() {
  alert("Selamat Anda Berhasil Bergabung");
}
function keluar() {
  alert("Anda Keluar Dari Event");
}
</script>