-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2023 at 07:13 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `temenin_gueh`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_chat`
--

CREATE TABLE `tb_chat` (
  `id_chat` int(11) NOT NULL,
  `id_event` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `isi_chat` text NOT NULL,
  `posted` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_chat`
--

INSERT INTO `tb_chat` (`id_chat`, `id_event`, `id_member`, `isi_chat`, `posted`) VALUES
(1, 2, 5, 'kenapa bro ?', '2018-01-08 23:41:44'),
(2, 2, 5, 'ass', '2018-01-08 23:41:50'),
(3, 2, 5, 'assalamualaikum..', '2018-01-08 23:42:14'),
(4, 2, 1, 'gak apa\"..', '2018-01-08 23:42:44'),
(5, 29, 0, 'hai', '2023-01-13 00:26:29'),
(6, 35, 0, 'pepepepepe', '2023-02-03 12:02:09'),
(14, 42, 5, 'test', '2023-02-06 01:08:13'),
(15, 40, 5, 'test', '2023-02-06 01:08:24');

-- --------------------------------------------------------

--
-- Table structure for table `tb_event`
--

CREATE TABLE `tb_event` (
  `id_event` int(11) NOT NULL,
  `nama_event` varchar(30) NOT NULL,
  `deskripsi` text NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  `jumlah_peserta` int(11) NOT NULL,
  `biaya` int(11) NOT NULL,
  `lokasi` text NOT NULL,
  `banner_event` varchar(30) NOT NULL,
  `pj_event` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_event`
--

INSERT INTO `tb_event` (`id_event`, `nama_event`, `deskripsi`, `tanggal`, `waktu`, `jumlah_peserta`, `biaya`, `lokasi`, `banner_event`, `pj_event`, `id_kategori`) VALUES
(1, 'Futsalicious Jawa Barat 2017', 'Pertandingan Futsal dalam rangka Bacot Festival untuk tingkat SD, SMP, SMA, Mahasiswa seJawa Barat', '2018-02-03', '08:00:00', 32, 200000, 'Lapangan Futsal Progresiv', 'futsal-2.jpg', 2, 1),
(33, 'ABIDIN GOW', 'langsung gow pokonya', '2023-02-13', '15:00:00', 10, 20000, 'Gor C-Tra Cikutra', '77883-ss1.jpg', 0, 2),
(35, 'Basket Madeppp', 'Gaskeun brayyy tipis tipisss', '2023-02-28', '18:00:00', 15, 25000, 'Gor C-Tra', '95860-beebucks.jpg', 0, 3),
(36, 'ATMOSPHERE', 'persehatan duniawi', '2023-02-21', '16:00:00', 20, 20000, 'Progresif', '6191-juvefutsal.png', 2, 1),
(40, 'Ligue', 'Gasgasgas', '2023-03-10', '15:00:00', 30, 30000, 'Gor Progresif', '21632-futsal1.jpg', 8, 1),
(41, 'Badbadmington', 'badmington chil', '2023-05-22', '15:15:00', 14, 15000, 'Gor BIC', '64020-bad1.jpg', 6, 2),
(42, 'Buasket Mas', 'Sokin basket ngab', '2020-04-05', '15:15:00', 20, 25000, 'Gor C-Tra', '8972-bas1.jpg', 5, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_join`
--

CREATE TABLE `tb_join` (
  `id_join` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `id_event` int(11) NOT NULL,
  `tanggal_join` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_join`
--

INSERT INTO `tb_join` (`id_join`, `id_member`, `id_event`, `tanggal_join`) VALUES
(6, 1, 1, '2018-01-02 00:30:14'),
(7, 5, 2, '2018-01-02 00:30:14'),
(8, 4, 3, '2018-01-02 00:30:14'),
(9, 15, 4, '2018-01-02 00:30:14'),
(10, 12, 5, '2018-01-02 00:30:14'),
(11, 10, 6, '2018-01-02 00:30:14'),
(12, 16, 7, '2018-01-02 00:30:14'),
(13, 6, 8, '2018-01-02 00:30:14'),
(14, 2, 9, '2018-01-02 00:30:14'),
(15, 1, 4, '2018-01-02 00:40:30'),
(32, 1, 2, '2018-01-08 23:43:23'),
(33, 0, 29, '2023-02-12 00:00:00'),
(35, 0, 35, '2023-02-03 12:01:58'),
(37, 2, 37, '2023-02-03 18:29:29'),
(61, 8, 40, '2023-03-10 00:00:00'),
(62, 6, 41, '2023-05-22 00:00:00'),
(63, 5, 42, '2020-04-05 00:00:00'),
(64, 5, 41, '2023-02-06 01:05:06'),
(65, 5, 40, '2023-02-06 01:08:32');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Futsal'),
(2, 'Badminton'),
(3, 'Basket');

-- --------------------------------------------------------

--
-- Table structure for table `tb_lokasi`
--

CREATE TABLE `tb_lokasi` (
  `id_lokasi` int(11) NOT NULL,
  `nama_event` varchar(60) NOT NULL,
  `alamat_lokasi` varchar(60) NOT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `kategori` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_lokasi`
--

INSERT INTO `tb_lokasi` (`id_lokasi`, `nama_event`, `alamat_lokasi`, `lat`, `lng`, `kategori`) VALUES
(0, 'bola', '1212312sdfsdf', 0, 0, 'Futsal'),
(2, 'Futsal bareng Alumni MAN 12', 'Lapangan Futsal Kosambi Baru', -6.18132, 106.719, 'futsal'),
(3, 'Belajar Badminton', 'GOR Grogol', -6.17784, 106.781, 'badminton'),
(4, 'Car Free Day Dago', 'Dago Bandung', -6.87726, 107.617, 'jogging'),
(5, 'Persiapan ISAC', 'Lapangan Futsal Mayasari', -6.93705, 107.718, 'futsal'),
(6, 'Voli UIN Bandung vs Jakarta', 'Lapangan Voli UIN Bandung', -6.93145, 107.719, 'voli'),
(7, 'Jogging ke Manglayang', 'Gunung Manglayang Bandung', -6.87611, 107.744, 'jogging'),
(8, 'Persiapan Universal Open', 'Lapangan Voli Pesantren Gomlay', 0, 0, 'voli'),
(9, 'Bulutangkis Go', 'GOR Cikutra', -6.89334, 107.64, 'badminton'),
(10, 'Futsalicious Jawa Barat 2017', 'Lapangan Futsal Progresiv', -6.93316, 107.686, 'futsal');

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE `tb_member` (
  `id_member` int(11) NOT NULL,
  `nama_member` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(2) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(16) NOT NULL,
  `email` varchar(30) NOT NULL,
  `hobi` varchar(10) NOT NULL,
  `bio` text NOT NULL,
  `foto` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`id_member`, `nama_member`, `jenis_kelamin`, `alamat`, `no_hp`, `email`, `hobi`, `bio`, `foto`) VALUES
(5, 'abdul', 'L', 'Jl. Sekeloa No.07', '088888888881', 'abdul@gmail.com', 'Mancing', 'Mancing keributan maksudnya', '80467-orgil1.jpg'),
(6, 'Daffa', 'L', 'Jl. Muararajeun Kulon No.7', '0895356401866', 'daffabs2001@gmail.com', 'mengaji', '1 malam 1 juz', '68675-hehe.jpg'),
(7, 'dimas', '', '', '', 'dimas@gmail.com', '', '', NULL),
(8, 'alfi', 'L', 'Jl. Cikutra No.08', '09999999999', 'alfi@gmail.com', 'Manjat', 'Manjat pohon pisang maksudnya', '9242-orgil2.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `level` varchar(15) NOT NULL,
  `id_member` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`, `level`, `id_member`) VALUES
(1, 'bedulrojak', '123', 'member', 5),
(2, 'daffa', '123', 'member', 6),
(3, 'dimas', '123', 'member', 7),
(4, 'alfi', '123', 'member', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_chat`
--
ALTER TABLE `tb_chat`
  ADD PRIMARY KEY (`id_chat`),
  ADD KEY `id_member` (`id_member`),
  ADD KEY `id_event` (`id_event`);

--
-- Indexes for table `tb_event`
--
ALTER TABLE `tb_event`
  ADD PRIMARY KEY (`id_event`),
  ADD KEY `id_kategori` (`id_kategori`),
  ADD KEY `id_member` (`pj_event`);

--
-- Indexes for table `tb_join`
--
ALTER TABLE `tb_join`
  ADD PRIMARY KEY (`id_join`),
  ADD KEY `id_member` (`id_member`),
  ADD KEY `id_event` (`id_event`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_lokasi`
--
ALTER TABLE `tb_lokasi`
  ADD PRIMARY KEY (`id_lokasi`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_member` (`id_member`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_chat`
--
ALTER TABLE `tb_chat`
  MODIFY `id_chat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tb_event`
--
ALTER TABLE `tb_event`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tb_join`
--
ALTER TABLE `tb_join`
  MODIFY `id_join` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
