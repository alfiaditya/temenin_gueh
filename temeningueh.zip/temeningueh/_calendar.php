
<?php

include_once('_functioncalendar.php');

?>

<div class="card mb-4">
    <center>
    <h5 class="card-header">Kalender</h5>
    </center>
    <div class="card-bodyco">
        <div id="calendar_div">
            <?php echo getCalender(); ?>
        </div>
    </div>
</div>