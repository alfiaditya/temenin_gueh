<header class="business-header">
	<div class="container">
    	<div class="row">
    		<div class="col-lg-12" style="margin-top: 20px;">
        		<h1 class="display-4 text-center mt-4">Kategori</h1>
        	</div>
        </div>
    </div>
</header>