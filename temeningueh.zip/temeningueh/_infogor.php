<div class="container text-center">
<h2 class="mt-4 text-center" >FUTSAL</h2>
<div class="row">
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/queenfutsal.jfif" alt="Kategori Futsal" ></a>
			<h5 class="card-title">Queen Futsal</h5>
			<p class="card-text"><small class="text-muted">Jl. Brigadir Jend. Katamso No.66, Cihaur Geulis, Kec. Cibeunying Kidul, Kota Bandung, Jawa Barat 40122
				<br>
			08.00 - 00.00
			<br>
			811-2233-8005
			<br>
			Jawa Barat</small></p>
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/progresiffutsal.jpg" alt="Kategori Volly"></a>
			<h5 class="card-title">Progresif Futsal</h5>
			<p class="card-text"><small class="text-muted">Jl. Soekarno Hatta No.785A, Babakan Penghulu, Kec. Cinambo, Kota Bandung, Jawa Barat 40293
				<br>
			08.00 - 23.00
			<br>
			(022) 7801616
			<br>
			Jawa Barat</small></p>
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/terbaikfutsal.jpeg" alt="Kategori Badminton"></a>
			<h5 class="card-title">Meteor Futsal</h5>
			<p class="card-text"><small class="text-muted">Jl. Terusan Jakarta, Antapani Kulon, Kec. Antapani, Kota Bandung, Jawa Barat 40291
				<br>
			08.00 - 23.00
			<br>
			(022) 92630499
			<br>
			Jawa Barat</small></p>
		</div>
	</div>

    <div class="container text-center">
    <h2 class="mt-4 text-center" >BASKET</h2>
    <div class="row">
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/ctrabasket.jpg" alt="Kategori Futsal" ></a>
			<h5 class="card-title">C-tra Basket</h5>
			<p class="card-text"><small class="text-muted">Jl. Cikutra No.278, Neglasari, Kec. Cibeunying Kaler, Kota Bandung, Jawa Barat 40124
				<br>
			08.00 - 22.00
			<br>
			- - - 
			<br>
			Jawa Barat</small></p>	
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/beebucks.jpg" alt="Kategori Volly"></a>
			<h5 class="card-title">Beebucks Basket</h5>
			<p class="card-text"><small class="text-muted">Jl. Halimun No.36, Malabar, Kec. Lengkong, Kota Bandung, Jawa Barat 40262
				<br>
			08.00 - 22.00
			<br>
			0895-2893-4634
			<br>
			Jawa Barat</small></p>	
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/saparua.jpg" alt="Kategori Badminton"></a>
			<h5 class="card-title">Saparua Basket</h5>
			<p class="card-text"><small class="text-muted">Jl. Banda No.28, Citarum, Kec. Bandung Wetan, Kota Bandung, Jawa Barat 40115
				<br>
			08.00 - 18.00
			<br>
			- - - -
			<br>
			Jawa Barat</small></p>	
		</div>
	</div>

    <div class="container text-center">
    <h2 class="mt-4 text-center" >BADMINTON</h2>
    <div class="row">
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/bd1.jpg" alt="Kategori Futsal" ></a>
			<h5 class="card-title">Lodaya Badminton</h5>
			<p class="card-text"><small class="text-muted">Jl. Lodaya No.20, Malabar, Kec. Lengkong, Kota Bandung, Jawa Barat 40262
				<br>
			08.00 - 00.00
			<br>
			- - - -
			<br>
			Jawa Barat</small></p>	
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/BIC.jpg" alt="Kategori Volly"></a>
			<h5 class="card-title">BIC Badminton</h5>
			<p class="card-text"><small class="text-muted">Jl. Soekarno Hatta Jl. Batununggal Indah IX No.2, Mengger, Kec. Bandung Kidul, Kota Bandung, Jawa Barat 40266
				<br>
			08.00 - 16.00
			<br>
			- - - -
			<br>
			Jawa Barat</small></p>
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a><img class="card-img-top" src="images/prestasi.jpg" alt="Kategori Badminton"></a>
			<h5 class="card-title">Prestasi Badminton</h5>
			<p class="card-text"><small class="text-muted">Jl. Muararajeun, Cihaur Geulis, Kec. Cibeunying Kaler, Kota Bandung, Jawa Barat 40122
				<br>
			08.00 - 22.00
			<br>
			(022) 7273370
			<br>
			Jawa Barat</small></p>
		</div>
	</div>
</div>