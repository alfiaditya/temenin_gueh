<h2 class="mt-4 text-center" style="margin-bottom: 40px;">MAPS</h2>
<div id="map" style="width: 100%; height: 600px; margin-top: 40px; margin-bottom: 40px;"></div>