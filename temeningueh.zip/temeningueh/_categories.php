<div class="card my-4">
    <center>
    <h5 class="card-header">Kategori</h5>
    </center>
    <div class="card-bodyco">
        <div class="row">
            <div class="col-lg-6">
                <ul class="list-unstyled mb-2" >
                    <?php

                    $cat=mysqli_query($conn,"SELECT * FROM tb_kategori");

                    while($c=mysqli_fetch_array($cat)){
                        $id_kategori = $c['id_kategori'];
                        $kategori = $c['nama_kategori'];
                    ?>
                    <li><a href="event.php?id_kategori=<?php echo $id_kategori;?>"><?php echo $kategori;?></a></li>
                    <?php }?>
                </ul>
            </div>
        </div>
    </div>
</div>