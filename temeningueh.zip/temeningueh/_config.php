<?php
    $host    = "localhost";
    $user    = "root";
    $pass    = "";
    $dbname = "temenin_gueh";
    
    $conn = mysqli_connect($host,$user,$pass,$dbname) or die ('Error');

    
         $baseurl="http://localhost/temenin_gueh/";
?>