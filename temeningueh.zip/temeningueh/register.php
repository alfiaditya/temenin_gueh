<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TEMENIN GUEH</title>

    <link rel="shortcut icon" type="image/png" href="images/icontg.png"/>

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    <link href="css/daflog.css" rel="stylesheet">
</head>
<?php

include('_config.php');

if(isset($_POST['register'])) {
    $nama_member=$_POST['nama_depan'];
    $jenis_kelamin=$_POST['jenis_kelamin'] ?? '';
    $alamat=$_POST['alamat'] ?? '0';
    $no_hp=$_POST['no_hp'] ?? '0';
    $email=$_POST['email'];
    $hobi=$_POST['hobi'] ?? '0';
    $bio=$_POST['bio'] ?? '0';
    $username=$_POST['username'];
    if($_POST['password_1']==$_POST['password_2']){
        $password=$_POST['password_1'];
    }

    $hasil=mysqli_query($conn,"INSERT INTO tb_member SET nama_member='$nama_member', email='$email'");
    if($hasil){
        $get_id=mysqli_query($conn,"SELECT id_member FROM tb_member WHERE email='$email'") or die (error_reporting());
        $c=mysqli_fetch_array($get_id);
        $id_member=$c['id_member'];

        $hasil_user=mysqli_query($conn,"INSERT INTO tb_user SET username='$username', password='$password', level='member', id_member='$id_member'");
        if($hasil_user){
            header("location:login.php");
        }
    }
} 
?>

<body>
<div class="container">
    <div class="box">
        <div class="row contenForm">
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <br>
                    <br>
                    <br>
                    <br>
                    <img src="images/Temenin Gueh.png" alt="" class="img-fluid">
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <br>
                    <b><h3 class="text-center">DAFTAR DISINI</h3></b>
                    <br>
                    <form method="post">
                    <div class="form-group">  
                                <label for="nama">Nama</label>
                                <input name="nama_depan" class="form-control" id="namaDepan" type="text" aria-describedby="nameHelp" placeholder="Masukkan Nama Depan">     
                    </div>
                    <div class="form-group">
                                <label for="email">Email</label>
                                <input name="email" class="form-control" id="email" type="email" aria-describedby="nameHelp" placeholder="Masukkan Email">
                    </div>
                    <div class="form-group">

                        <label for="username">Username</label>
                        <input name="username" class="form-control" id="username" type="text" aria-describedby="emailHelp" placeholder="Masukkan Username">
                    </div>
                    <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input name="password_1" class="form-control" id="exampleInputPassword1" type="password" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <label for="exampleConfirmPassword">Confirm password</label>
                                <input name="password_2" class="form-control" id="exampleConfirmPassword" type="password" placeholder="Confirm password">
                            </div>
                            <br>
                            <button name="register" class="btn btn-primary btn-block" onclick="daftar()">Daftar</button>
                </form>
                <div class="text-center">
                    <a class="d-block small mt-3" href="login.php">Sudah punya akun ? Login di sini</a>
                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script>
function daftar() {
  alert("Selamat Registrasi Anda Berhasil");
}
</script>
</body>
</html>