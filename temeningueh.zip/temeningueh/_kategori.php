<div class="container text-center">
<h2 class="mt-4 text-center" >KATEGORI</h2>
<div class="row">
	<div class="col-sm-4 my-4">
		<div class="card">
			<a href="event.php?id_kategori=1"><img class="card-img-top" src="images/bola1.jpg" alt="Kategori Futsal" ></a>
			<h5 class="card-title">FUTSAL</h5>
			<p class="card-text"><small class="text-muted">Futsal adalah permainan bola yang dimainkan oleh dua regu, yang masing- masing beranggotakan lima orang. Tujuannya adalah memasukkan bola ke gawang lawan</small></p>
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a href="event.php?id_kategori=2"><img class="card-img-top" src="images/badminton1.jpg" alt="Kategori Volly"></a>
			<h5 class="card-title">BADMINTON</h5>
			<p class="card-text"><small class="text-muted">badminton adalah suatu olahraga raket yang dimainkan oleh dua orang (untuk tunggal) atau dua pasangan (untuk ganda) yang saling berlawanan.</small></p>
		</div>
	</div>
	<div class="col-sm-4 my-4">
		<div class="card">
			<a href="event.php?id_kategori=3"><img class="card-img-top" src="images/basket2.png" alt="Kategori Badminton"></a>
			<h5 class="card-title">BASKET</h5>
			<p class="card-text"><small class="text-muted">basket adalah olahraga bola berkelompok yang terdiri dua tim beranggotakan masing-masing lima orang yang saling bertanding mencetak poin.</small></p>
		</div>
	</div>
</div>